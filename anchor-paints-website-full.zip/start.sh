#!/bin/bash
echo "Starting Anchor Paints website..."
export NODE_ENV=production
export PORT=5001
node simple-server.js