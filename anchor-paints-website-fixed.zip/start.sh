#!/bin/bash
echo "Starting Anchor Paints website..."
node start.js
